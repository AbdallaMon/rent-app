"use client";

export default function WhatsAppDashboard() {}
