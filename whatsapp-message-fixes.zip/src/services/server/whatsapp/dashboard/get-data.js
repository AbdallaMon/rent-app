import prisma from "@/lib/prisma";
import { DEFAULT_REMINDER, DEFAULT_TEAM } from "./defaults";

export async function getWhatsAppSettings() {
  const [reminder, team] = await Promise.all([
    prisma.reminderSettings.findFirst({
      where: { id: "default_reminder_settings" },
    }),
    prisma.whatsAppTeamSettings.findFirst({
      where: { id: "default_team_settings" },
    }),
  ]);

  return {
    reminderSettings: reminder || DEFAULT_REMINDER,
    teamSettings: team || DEFAULT_TEAM,
  };
}
