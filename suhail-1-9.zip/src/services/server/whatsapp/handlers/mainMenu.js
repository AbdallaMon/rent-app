import {
  withReadOnlyConnection,
  withWriteConnection,
} from "@/lib/database-connection";
import { sendWhatsAppMessage } from "@/lib/whatsapp";
import { findClientWithPropertyProduction } from "../services/clients";
import { getClientRequestHistory } from "../services/history";
import { sendMain } from "../responders";
import { LANG } from "../services/constants";

export async function handleStatus(phone, language) {
  const ar = language === LANG.AR;
  const res = await getClientRequestHistory(phone, 5);
  if (!res?.success) {
    await sendWhatsAppMessage(
      phone,
      ar
        ? "❌ لم نجد حسابك. يرجى الاتصال: +971507935566"
        : "❌ We couldn't find your account. Please call: +971507935566"
    );
    return sendMain(phone, language);
  }

  const {
    client,
    maintenanceRequests = [],
    complaints = [],
    totalRequests = 0,
  } = res.data || {};
  if (!totalRequests) {
    await sendWhatsAppMessage(
      phone,
      ar
        ? `📊 لا توجد طلبات سابقة، ${client?.name || ""}`
        : `📊 No previous requests, ${client?.name || ""}`
    );
    return sendMain(phone, language);
  }

  let msg = ar
    ? `📊 حالة طلبات ${client?.name}\n\n`
    : `📊 ${client?.name}'s Requests\n\n`;
  if (maintenanceRequests.length) {
    msg += ar
      ? `🔧 طلبات الصيانة (${maintenanceRequests.length}):\n`
      : `🔧 Maintenance (${maintenanceRequests.length}):\n`;
    maintenanceRequests.forEach((r, i) => {
      const id = r.displayId || r.id;
      msg += `${i + 1}. #\u202D${id}\u202C • ${r.status}\n`;
    });
    msg += "\n";
  }
  if (complaints.length) {
    msg += ar
      ? `📝 الشكاوى (${complaints.length}):\n`
      : `📝 Complaints (${complaints.length}):\n`;
    complaints.forEach((c, i) => {
      const id = c.displayId || c.id;
      msg += `${i + 1}. #\u202D${id}\u202C • ${c.status}\n`;
    });
    msg += "\n";
  }

  await sendWhatsAppMessage(phone, msg.trim());
  return sendMain(phone, language);
}

export async function handleSupport(phone, language) {
  const ar = language === LANG.AR;
  const found = await findClientWithPropertyProduction(phone);
  if (!found?.success || !found?.client) {
    await sendWhatsAppMessage(
      phone,
      ar
        ? "❌ لم نجد حسابك. يرجى الاتصال: +971507935566"
        : "❌ We couldn't find your account. Please call: +971507935566"
    );
    return sendMain(phone, language);
  }
  await withWriteConnection(async (prisma) => {
    await prisma.contact.create({
      data: {
        name: found.client.name,
        phone,
        description: `طلب دعم عبر البوت - ${new Date().toISOString()}`,
      },
    });
  });
  await sendWhatsAppMessage(
    phone,
    ar
      ? "✅ تم تسجيل طلب الدعم. سيتواصل معك فريقنا قريباً."
      : "✅ Support request recorded. Our team will contact you shortly."
  );
  return sendMain(phone, language);
}

export async function handlePayments(phone, language) {
  const ar = language === LANG.AR;
  const found = await findClientWithPropertyProduction(phone);
  if (!found?.success || !found?.client) {
    await sendWhatsAppMessage(
      phone,
      ar
        ? "❌ لم نجد حسابك. اتصل بنا للاستعلام عن الدفعات."
        : "❌ We couldn't find your account. Please call us for payment info."
    );
    return sendMain(phone, language);
  }

  await withReadOnlyConnection(async (prisma) => {
    const agreements = await prisma.rentAgreement.findMany({
      where: { renterId: found.client.id },
      include: {
        property: true,
        unit: true,
        payments: {
          where: { status: "PENDING" },
          orderBy: { dueDate: "asc" },
          take: 3,
        },
      },
    });

    if (!agreements.length) {
      await sendWhatsAppMessage(
        phone,
        ar ? "لا توجد دفعات معلقة." : "No pending payments."
      );
      return;
    }

    let text = ar ? "💳 الدفعات المستحقة:\n\n" : "💳 Pending payments:\n\n";
    for (const ag of agreements) {
      for (const p of ag.payments) {
        const id = p.displayId || p.id;
        const due = new Date(p.dueDate).toLocaleDateString("en-US");
        text += ar
          ? `#\u202D${id}\u202C • ${ag.property?.name || ""} • ${ag.unit?.number || ""}\n📅 ${due} • 💰 ${p.amount} درهم\n\n`
          : `#\u202D${id}\u202C • ${ag.property?.name || ""} • ${ag.unit?.number || ""}\n📅 ${due} • 💰 ${p.amount} AED\n\n`;
      }
    }
    await sendWhatsAppMessage(phone, text.trim());
  });

  return sendMain(phone, language);
}

export async function handleRenewal(phone, language) {
  const ar = language === LANG.AR;
  const found = await findClientWithPropertyProduction(phone);
  if (!found?.success || !found?.client) {
    await sendWhatsAppMessage(
      phone,
      ar
        ? "❌ لم نجد حسابك. اتصل بنا لتجديد العقد."
        : "❌ We couldn't find your account. Please call us for renewal."
    );
    return sendMain(phone, language);
  }

  await withWriteConnection(async (prisma) => {
    await prisma.contact.create({
      data: {
        name: found.client.name,
        phone,
        description: `طلب تجديد عقد عبر البوت - ${new Date().toISOString()}`,
      },
    });
  });

  await sendWhatsAppMessage(
    phone,
    ar
      ? "✅ تم تسجيل طلب التجديد. سيتواصل معك فريق المبيعات خلال 24 ساعة."
      : "✅ Renewal request recorded. Sales team will contact you within 24 hours."
  );
  return sendMain(phone, language);
}
