import { withWriteConnection } from "@/lib/database-connection";
import { sendComplaintNotifications } from "@/lib/reliable-notifications";
import { TYPE_MAP_COMPLAINT, PRIORITIES } from "./constants";
import { findClientWithPropertyProduction } from "./clients";

async function generateComplaintDisplayId(prisma) {
  const seq = await prisma.complaint.count();
  return "CP-" + String(seq + 1).padStart(6, "0");
}

export async function createComplaintProduction(
  phoneNumber,
  description,
  session
) {
  return withWriteConnection(async (prisma) => {
    const clientData = await findClientWithPropertyProduction(phoneNumber);
    if (!clientData.success || !clientData.client) {
      return {
        success: false,
        message: "CLIENT_NOT_FOUND",
        data: null,
        error: "CLIENT_NOT_FOUND",
      };
    }

    const { client, property, unit } = clientData;
    const displayId = await generateComplaintDisplayId(prisma);

    const inputCategory = (session?.data?.category || "other").toLowerCase();
    const mappedCategory = TYPE_MAP_COMPLAINT[inputCategory] || "OTHER";

    let priority = (session?.data?.priority || "MEDIUM").toUpperCase();
    if (!PRIORITIES.includes(priority)) {
      const map = {
        urgent: "URGENT",
        high: "HIGH",
        medium: "MEDIUM",
        low: "LOW",
      };
      priority = map[(session?.data?.priority || "").toLowerCase()] || "MEDIUM";
    }

    const complaint = await prisma.complaint.create({
      data: {
        displayId,
        clientId: client.id,
        propertyId: property?.id || null,
        unitId: unit?.id || null,
        description,
        type: mappedCategory,
        priority,
        status: "PENDING",
      },
      include: { client: true, property: true, unit: true },
    });

    try {
      await sendComplaintNotifications({
        complaintId: complaint.id,
        displayId: complaint.displayId,
        clientName: client.name,
        clientPhone: phoneNumber,
        complaintType: complaint.type,
        priority: complaint.priority,
        description,
        propertyName: property?.name || "غير محدد",
        unitNumber:
          unit?.number ||
          unit?.unitId ||
          (unit?.floor ? `الطابق ${unit.floor}` : "غير محدد"),
      });
    } catch (e) {
      console.warn("Complaint notifications failed:", e?.message);
    }

    return { success: true, data: { complaint, client, property, unit } };
  });
}
