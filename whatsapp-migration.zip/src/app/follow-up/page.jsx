"use client";
import React from 'react'
import { HomePage } from './follow-up';

const FollowUpPage = () => {
  return (
    <div><HomePage /></div>
  )
}

export default FollowUpPage
