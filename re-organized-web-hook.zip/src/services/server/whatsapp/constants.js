export const SESSION_TTL_MS = 30 * 60 * 1000;

export const LANG = {
  AR: "ARABIC",
  EN: "ENGLISH",
};

export const DEFAULT_LANG = LANG.AR;

export const PRIORITIES = ["LOW", "MEDIUM", "HIGH", "URGENT"];

export const TYPE_MAP_MAINT = {
  electrical: "ELECTRICAL",
  plumbing: "PLUMBING",
  ac_heating: "AC_HEATING",
  appliances: "APPLIANCES",
  structural: "STRUCTURAL",
  cleaning: "CLEANING",
  painting: "PAINTING",
  carpentry: "CARPENTRY",
  pest_control: "PEST_CONTROL",
  other: "OTHER",
  other_maintenance: "OTHER",
};

export const TYPE_MAP_COMPLAINT = {
  property_issue: "PROPERTY_ISSUE",
  rent_issue: "RENT_ISSUE",
  neighbor_issue: "NEIGHBOR_ISSUE",
  maintenance_issue: "MAINTENANCE_ISSUE",
  noise_issue: "NOISE_ISSUE",
  security_issue: "SECURITY_ISSUE",
  payment_issue: "PAYMENT_ISSUE",
  service_quality: "SERVICE_QUALITY",
  other_complaint: "OTHER",
  other: "OTHER",
};
