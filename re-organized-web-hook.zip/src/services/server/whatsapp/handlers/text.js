import { LANG } from "../constants";
import { getSession, setSession } from "../session";
import {
  sendLanguage,
  sendMain,
  sendMaintenanceConfirmation,
  sendComplaintConfirmation,
} from "../responders";
import { createMaintenanceRequestProduction } from "../services/maintenance";
import { createComplaintProduction } from "../services/complaints";

export async function handleTextMessage(phone, text) {
  const sess = getSession(phone);
  if (!sess) return sendLanguage(phone);

  const language = sess.language || LANG.AR;
  const ar = language === LANG.AR;
  const t = (text || "").toLowerCase().trim();

  switch (sess.step) {
    case "awaiting_language_selection":
      if (t === "1" || t.includes("english")) return sendMain(phone, LANG.EN);
      if (t === "2" || t.includes("عرب")) return sendMain(phone, LANG.AR);
      return sendLanguage(phone);

    case "awaiting_description": {
      const res = await createMaintenanceRequestProduction(phone, text, sess);
      if (!res?.success) {
        await sendMain(phone, language);
        return;
      }
      const r = res.data?.request;
      await sendMaintenanceConfirmation(phone, language, {
        id: r?.displayId || r?.id,
        property: res.data?.property?.name || (ar ? "غير محدد" : "N/A"),
        unit:
          res.data?.unit?.number ||
          res.data?.unit?.unitId ||
          (ar ? "غير محدد" : "N/A"),
        type: r?.type || "OTHER",
        priority: r?.priority || "MEDIUM",
        desc: text,
      });
      setSession(phone, { data: {}, step: "completed" });
      return;
    }

    case "awaiting_complaint_description": {
      const res = await createComplaintProduction(phone, text, sess);
      if (!res?.success) {
        await sendMain(phone, language);
        return;
      }
      const c = res.data?.complaint;
      await sendComplaintConfirmation(phone, language, {
        id: c?.displayId || c?.id,
        property: res.data?.property?.name || (ar ? "غير محدد" : "N/A"),
        unit:
          res.data?.unit?.number ||
          res.data?.unit?.unitId ||
          (ar ? "غير محدد" : "N/A"),
        type: c?.type || "OTHER",
        priority: c?.priority || "MEDIUM",
        desc: text,
      });
      setSession(phone, { data: {}, step: "completed" });
      return;
    }

    case "completed":
      return sendMain(phone, language);

    default:
      return sendMain(phone, language);
  }
}
