 
const nextConfig = {
  turbopack: {
  },
}
 
export default nextConfig