// // app/api/whatsapp/webhook/route.js

// import { NextResponse } from "next/server";
// import {
//   sendInteractiveWhatsAppMessage,
//   sendWhatsAppMessage,
// } from "@/lib/whatsapp";

// import {
//   withReadOnlyConnection,
//   withWriteConnection,
// } from "@/lib/database-connection";

// import {
//   buildPhoneVariants,
//   cleanDigits,
//   splitCountryCode,
//   normalizePhone,
// } from "@/lib/phone";
// import {
//   sendMaintenanceNotifications,
//   sendComplaintNotifications,
// } from "@/lib/reliable-notifications";
// const sessions = new Map(); // phone -> { language, step, data, ts }
// const processedMsgIds = new Set(); // dedupe WA message ids
// const SESSION_TTL_MS = 30 * 60 * 1000;

// function now() {
//   return Date.now();
// }

// function pruneOldSessions() {
//   const cutoff = now() - SESSION_TTL_MS;
//   for (const [k, v] of sessions.entries()) {
//     if ((v?.ts || 0) < cutoff) sessions.delete(k);
//   }
// }
// setInterval(pruneOldSessions, 15 * 60 * 1000);

// /* ================
//    Session helpers
//    ================ */
// function getSession(phone) {
//   return sessions.get(phone);
// }
// function setSession(phone, patch) {
//   const cur = getSession(phone) || {
//     language: "ARABIC",
//     step: "greeting",
//     data: {},
//   };
//   const next = { ...cur, ...patch, ts: now() };
//   sessions.set(phone, next);
//   return next;
// }

// /* =========================================
//    Menu builders (interactive payloads only)
//    ========================================= */
// function menuLanguage() {
//   return {
//     type: "button",
//     header: { type: "text", text: "🌍 Language Selection / اختيار اللغة" },
//     body: {
//       text: "Welcome! Please choose your language.\n\nمرحباً! اختر لغتك.",
//     },
//     footer: { text: "Choose / اختر" },
//     action: {
//       buttons: [
//         { type: "reply", reply: { id: "lang_en", title: "🇺🇸 English" } },
//         { type: "reply", reply: { id: "lang_ar", title: "🇦🇪 العربية" } },
//       ],
//     },
//   };
// }

// function menuMain(language) {
//   const ar = language === "ARABIC";
//   return {
//     type: "list",
//     header: { type: "text", text: ar ? "خدمات العملاء" : "Customer Services" },
//     body: {
//       text: ar
//         ? "مرحباً! يرجى اختيار الخدمة:"
//         : "Welcome! Please select a service:",
//     },
//     footer: { text: ar ? "نحن هنا لخدمتك" : "We’re here to help" },
//     action: {
//       button: ar ? "اختر الخدمة" : "Select Service",
//       sections: [
//         {
//           title: ar ? "الخدمات المتاحة" : "Available Services",
//           rows: [
//             {
//               id: "maintenance_request",
//               title: ar ? "🔧 طلب صيانة" : "🔧 Maintenance Request",
//             },
//             {
//               id: "submit_complaint",
//               title: ar ? "📝 تقديم شكوى" : "📝 Submit Complaint",
//             },
//             {
//               id: "check_status",
//               title: ar ? "📊 حالة الطلبات" : "📊 Check Status",
//             },
//             {
//               id: "contact_support",
//               title: ar ? "☎️ الاتصال بالدعم" : "☎️ Contact Support",
//             },
//             {
//               id: "payment_inquiry",
//               title: ar ? "💳 استعلام عن الدفعات" : "💳 Payment Inquiry",
//             },
//             {
//               id: "contract_renewal",
//               title: ar ? "📋 تجديد العقد" : "📋 Contract Renewal",
//             },
//           ],
//         },
//       ],
//     },
//   };
// }

// function menuMaintenanceType(language) {
//   const ar = language === "ARABIC";
//   return {
//     type: "list",
//     header: {
//       type: "text",
//       text: ar ? "نوع طلب الصيانة" : "Maintenance Request Type",
//     },
//     body: { text: ar ? "اختر نوع المشكلة:" : "Select the issue type:" },
//     action: {
//       button: ar ? "اختر النوع" : "Select Type",
//       sections: [
//         {
//           title: ar ? "أنواع الصيانة" : "Types",
//           rows: [
//             { id: "plumbing", title: ar ? "🚿 سباكة" : "🚿 Plumbing" },
//             { id: "electrical", title: ar ? "⚡ كهرباء" : "⚡ Electrical" },
//             {
//               id: "ac_heating",
//               title: ar ? "❄️ تكييف/تدفئة" : "❄️ AC & Heating",
//             },
//             { id: "appliances", title: ar ? "🏠 أجهزة" : "🏠 Appliances" },
//             { id: "structural", title: ar ? "🏗️ إنشائية" : "🏗️ Structural" },
//             {
//               id: "internet_cable",
//               title: ar ? "📡 إنترنت وكابل" : "📡 Internet & Cable",
//             },
//             {
//               id: "security_systems",
//               title: ar ? "🔒 أنظمة الأمان" : "🔒 Security Systems",
//             },
//             { id: "other_maintenance", title: ar ? "🔧 أخرى" : "🔧 Other" },
//           ],
//         },
//       ],
//     },
//   };
// }

// function menuPriority(language) {
//   const ar = language === "ARABIC";
//   return {
//     type: "list",
//     header: { type: "text", text: ar ? "أولوية الطلب" : "Request Priority" },
//     body: { text: ar ? "حدد أولوية الطلب:" : "Choose priority:" },
//     action: {
//       button: ar ? "اختر الأولوية" : "Select Priority",
//       sections: [
//         {
//           title: ar ? "الأولوية" : "Priority",
//           rows: [
//             { id: "urgent", title: ar ? "🔴 عاجل" : "🔴 Urgent" },
//             { id: "high", title: ar ? "🟠 عالية" : "🟠 High" },
//             { id: "medium", title: ar ? "🟡 متوسطة" : "🟡 Medium" },
//             { id: "low", title: ar ? "🟢 منخفضة" : "🟢 Low" },
//           ],
//         },
//       ],
//     },
//   };
// }

// function menuComplaintCategory(language) {
//   const ar = language === "ARABIC";
//   return {
//     type: "list",
//     header: { type: "text", text: ar ? "نوع الشكوى" : "Complaint Type" },
//     body: { text: ar ? "اختر نوع الشكوى:" : "Select complaint type:" },
//     action: {
//       button: ar ? "اختر النوع" : "Select Type",
//       sections: [
//         {
//           title: ar ? "الأنواع" : "Types",
//           rows: [
//             {
//               id: "property_issue",
//               title: ar ? "🏠 مشكلة في العقار" : "🏠 Property Issue",
//             },
//             {
//               id: "rent_issue",
//               title: ar ? "💰 مشكلة في الإيجار" : "💰 Rent Issue",
//             },
//             {
//               id: "neighbor_issue",
//               title: ar ? "👥 مشكلة مع الجيران" : "👥 Neighbor Issue",
//             },
//             {
//               id: "maintenance_issue",
//               title: ar ? "🔧 مشكلة في الصيانة" : "🔧 Maintenance Issue",
//             },
//             {
//               id: "noise_issue",
//               title: ar ? "🔊 مشكلة ضوضاء" : "🔊 Noise Issue",
//             },
//             {
//               id: "security_issue",
//               title: ar ? "🛡️ مشكلة أمنية" : "🛡️ Security Issue",
//             },
//             {
//               id: "payment_issue",
//               title: ar ? "💳 مشكلة في الدفع" : "💳 Payment Issue",
//             },
//             { id: "other_complaint", title: ar ? "📝 أخرى" : "📝 Other" },
//           ],
//         },
//       ],
//     },
//   };
// }

// /* ===================================================
//    Language / main menu senders (with safe fallbacks)
//    =================================================== */

// export async function findClientWithPropertyProduction(phoneNumber) {
//   return await withReadOnlyConnection(async (prisma) => {
//     try {
//       console.log(`🔍 [PRODUCTION] البحث عن العميل: ${phoneNumber}`);

//       const uniqueVariants = buildPhoneVariants(phoneNumber);
//       console.log(`🔍 البحث باستخدام الأرقام:`, uniqueVariants);

//       let client = await prisma.client.findFirst({
//         where: { phone: { in: uniqueVariants } },
//       });

//       if (!client) {
//         console.log(`🔍 البحث المباشر فشل، محاولة البحث الموسّع...`);

//         const cleaned = cleanDigits(phoneNumber);
//         const { core } = splitCountryCode(cleaned);
//         const probe = core || cleaned;
//         const lastDigits = probe.slice(-8); // نفس منطقك السابق

//         client = await prisma.client.findFirst({
//           where: {
//             OR: [
//               { phone: { endsWith: lastDigits } },
//               { phone: { contains: lastDigits } },
//               { phone: { contains: probe } },
//             ],
//           },
//         });
//       }

//       if (!client) {
//         console.log(`❌ لم يتم العثور على العميل نهائياً`);
//         const sampleClients = await prisma.client.findMany({
//           take: 5,
//           select: { id: true, name: true, phone: true },
//         });

//         return {
//           success: false,
//           message: "لم يتم العثور على العميل بهذا الرقم",
//           client: null,
//           property: null,
//           unit: null,
//           debug: { searchedVariants: uniqueVariants, sampleClients },
//         };
//       }

//       console.log(`✅ تم العثور على العميل: ${client.name} (ID: ${client.id})`);

//       // العقود النشطة
//       const rentAgreements = await prisma.rentAgreement.findMany({
//         where: { renterId: client.id, status: "ACTIVE" },
//         include: {
//           unit: { include: { property: true } },
//         },
//         orderBy: { createdAt: "desc" },
//       });

//       let property = null;
//       let unit = null;

//       if (rentAgreements.length > 0) {
//         const mainAgreement = rentAgreements[0];
//         property = mainAgreement.unit?.property || null;
//         unit = mainAgreement.unit || null;

//         if (property && unit) {
//           console.log(`🏠 العقار: ${property.name}, الوحدة: ${unit.number}`);
//         } else {
//           console.log(`ℹ️ عقد موجود لكن لم نجد property/unit بشكل كامل`);
//         }
//       } else {
//         console.log(`⚠️ لا توجد عقود إيجار نشطة للعميل`);
//       }

//       return {
//         success: true,
//         message: "تم العثور على العميل والعقار والوحدة بنجاح",
//         client,
//         property,
//         unit,
//         rentAgreements,
//       };
//     } catch (error) {
//       console.error("❌ خطأ في البحث عن العميل:", error);
//       console.error("📋 تفاصيل الخطأ الكاملة:", {
//         name: error.name,
//         message: error.message,
//         stack: error.stack,
//         phoneNumber,
//       });

//       return {
//         success: false,
//         message: "حدث خطأ أثناء البحث عن العميل",
//         client: null,
//         property: null,
//         unit: null,
//         error: error.message,
//       };
//     }
//   });
// }

// /**
//  * إنشاء طلب صيانة - النسخة المحسنة
//  */
// export async function createMaintenanceRequestProduction(
//   phoneNumber,
//   description,
//   session
// ) {
//   return await withWriteConnection(async (prisma) => {
//     try {
//       console.log(`🔧 [PRODUCTION] إنشاء طلب صيانة للرقم: ${phoneNumber}`);
//       console.log(`📝 الوصف: ${description}`);
//       console.log(`📋 Session:`, JSON.stringify(session, null, 2));

//       // البحث عن العميل
//       const clientData = await findClientWithPropertyProduction(phoneNumber);

//       if (!clientData.success || !clientData.client) {
//         console.error("❌ فشل في العثور على العميل:", clientData.message);
//         return {
//           success: false,
//           message: "لم يتم العثور على العميل. يرجى التأكد من رقم الهاتف.",
//           data: null,
//           error: "CLIENT_NOT_FOUND",
//           debug: clientData.debug,
//         };
//       }

//       const { client, property, unit } = clientData;
//       // تحضير البيانات مع التحقق من الصحة
//       const maintenanceData = {
//         clientId: client.id,
//         propertyId: property?.id || null,
//         unitId: unit?.id || null,
//         description: description,
//         type: "OTHER", // قيمة افتراضية آمنة من MaintenanceType enum
//         priority: "MEDIUM", // قيمة افتراضية آمنة
//         status: "PENDING",
//       };
//       // تحديث القيم من الجلسة إذا كانت متوفرة وصحيحة
//       if (session?.data?.maintenanceType) {
//         // إنشاء مطابقة بين القيم lowercase والـ enum UPPERCASE
//         const typeMapping = {
//           electrical: "ELECTRICAL",
//           plumbing: "PLUMBING",
//           ac_heating: "AC_HEATING",
//           appliances: "APPLIANCES",
//           structural: "STRUCTURAL",
//           cleaning: "CLEANING",
//           painting: "PAINTING",
//           carpentry: "CARPENTRY",
//           pest_control: "PEST_CONTROL",
//           other: "OTHER",
//           other_maintenance: "OTHER", // إضافة مطابقة للـ ID الصحيح
//         };

//         const inputType = session.data.maintenanceType.toLowerCase();
//         const mappedType = typeMapping[inputType];

//         console.log(`🔧 نوع الصيانة المرسل: ${session.data.maintenanceType}`);
//         console.log(`🔧 نوع الصيانة بعد التطبيع: ${inputType}`);
//         console.log(`🔧 نوع الصيانة المطابق: ${mappedType}`);

//         if (mappedType) {
//           maintenanceData.type = mappedType;
//         } else {
//           console.log(
//             `⚠️ نوع صيانة غير معروف: ${session.data.maintenanceType}, استخدام OTHER`
//           );
//           maintenanceData.type = "OTHER";
//         }
//       }

//       if (session?.data?.priority) {
//         const validPriorities = ["LOW", "MEDIUM", "HIGH", "URGENT"];
//         if (validPriorities.includes(session.data.priority.toUpperCase())) {
//           maintenanceData.priority = session.data.priority.toUpperCase();
//         }
//       }
//       console.log(`📊 بيانات طلب الصيانة النهائية:`, maintenanceData);

//       // توليد display ID مخصص
//       const displayId = await generateMaintenanceDisplayId();
//       maintenanceData.displayId = displayId;
//       console.log(`🔧 Display ID للطلب: ${displayId}`);

//       // إنشاء الطلب
//       const maintenanceRequest = await prisma.maintenanceRequest.create({
//         data: maintenanceData,
//         include: {
//           client: true,
//           property: true,
//           unit: true,
//         },
//       });
//       console.log(`✅ تم إنشاء طلب الصيانة بنجاح: ${maintenanceRequest.id}`);

//       // إرسال الإشعارات الموثوقة للفني وخدمة العملاء
//       try {
//         console.log(
//           `📤 إرسال إشعارات طلب الصيانة #${maintenanceRequest.id}...`
//         );
//         const notificationResult = await sendMaintenanceNotifications({
//           requestId: maintenanceRequest.id,
//           displayId: maintenanceRequest.displayId,
//           clientName: client.name,
//           clientPhone: phoneNumber,
//           maintenanceType: maintenanceRequest.type,
//           priority: maintenanceRequest.priority,
//           description: description,
//           propertyName: property?.name || "غير محدد",
//           unitNumber:
//             unit?.number ||
//             unit?.unitId ||
//             `الطابق ${unit?.floor || "غير محدد"}` ||
//             "غير محدد",
//         });

//         console.log(`📤 نتيجة إرسال الإشعارات:`, notificationResult);

//         if (notificationResult.success) {
//           console.log(
//             `✅ تم إرسال جميع الإشعارات بنجاح (${notificationResult.successCount}/${notificationResult.totalCount})`
//           );
//         } else {
//           console.log(
//             `⚠️ فشل في إرسال بعض الإشعارات (${notificationResult.successCount}/${notificationResult.totalCount})`
//           );
//         }
//       } catch (notificationError) {
//         console.error(`❌ خطأ في إرسال الإشعارات:`, notificationError);
//         // لا نوقف العملية حتى لو فشلت الإشعارات
//       }

//       return {
//         success: true,
//         message: "تم إنشاء طلب الصيانة بنجاح",
//         data: {
//           request: maintenanceRequest,
//           client: client,
//           property: property,
//           unit: unit,
//         },
//       };
//     } catch (error) {
//       console.error("❌ خطأ في إنشاء طلب الصيانة:", error);
//       console.error("📋 تفاصيل الخطأ الكاملة:", {
//         name: error.name,
//         message: error.message,
//         stack: error.stack,
//         phoneNumber: phoneNumber,
//         session: session,
//       });

//       return {
//         success: false,
//         message: "حدث خطأ أثناء إنشاء طلب الصيانة",
//         data: null,
//         error: error.message,
//       };
//     }
//   });
// }

// /**
//  * إنشاء شكوى - النسخة المحسنة
//  */
// export async function createComplaintProduction(
//   phoneNumber,
//   description,
//   session
// ) {
//   return await withWriteConnection(async (prisma) => {
//     try {
//       console.log(`📝 [PRODUCTION] إنشاء شكوى للرقم: ${phoneNumber}`);
//       console.log(`📄 الوصف: ${description}`);
//       console.log(`📋 Session كاملة:`, JSON.stringify(session, null, 2));
//       console.log(`📋 Session.data:`, JSON.stringify(session?.data, null, 2));
//       console.log(`📋 Session.data.category:`, session?.data?.category);

//       // البحث عن العميل
//       const clientData = await findClientWithPropertyProduction(phoneNumber);

//       if (!clientData.success || !clientData.client) {
//         console.error("❌ فشل في العثور على العميل:", clientData.message);
//         return {
//           success: false,
//           message: "لم يتم العثور على العميل. يرجى التأكد من رقم الهاتف.",
//           data: null,
//           error: "CLIENT_NOT_FOUND",
//           debug: clientData.debug,
//         };
//       }

//       const { client, property, unit } = clientData;

//       // تحضير البيانات مع التحقق من الصحة
//       const complaintData = {
//         clientId: client.id,
//         propertyId: property?.id || null,
//         unitId: unit?.id || null,
//         description: description,
//         type: "OTHER", // قيمة افتراضية آمنة
//         priority: "MEDIUM", // قيمة افتراضية آمنة
//         status: "PENDING",
//       };
//       // تحديث القيم من الجلسة إذا كانت متوفرة وصحيحة
//       if (session?.data?.category) {
//         // إنشاء مطابقة بين القيم lowercase والـ enum UPPERCASE
//         const categoryMapping = {
//           property_issue: "PROPERTY_ISSUE",
//           rent_issue: "RENT_ISSUE",
//           neighbor_issue: "NEIGHBOR_ISSUE",
//           maintenance_issue: "MAINTENANCE_ISSUE",
//           noise_issue: "NOISE_ISSUE",
//           security_issue: "SECURITY_ISSUE",
//           payment_issue: "PAYMENT_ISSUE",
//           service_quality: "SERVICE_QUALITY",
//           other_complaint: "OTHER",
//           other: "OTHER",
//         };

//         const inputCategory = session.data.category.toLowerCase();
//         const mappedCategory = categoryMapping[inputCategory];

//         console.log(`📝 نوع الشكوى المرسل: ${session.data.category}`);
//         console.log(`📝 نوع الشكوى بعد التطبيع: ${inputCategory}`);
//         console.log(`📝 نوع الشكوى المطابق: ${mappedCategory}`);

//         if (mappedCategory) {
//           complaintData.type = mappedCategory;
//         } else {
//           console.log(
//             `⚠️ نوع شكوى غير معروف: ${session.data.category}, استخدام OTHER`
//           );
//           complaintData.type = "OTHER";
//         }
//       }

//       if (session?.data?.priority) {
//         const validPriorities = ["LOW", "MEDIUM", "HIGH", "URGENT"];
//         if (validPriorities.includes(session.data.priority.toUpperCase())) {
//           complaintData.priority = session.data.priority.toUpperCase();
//         }
//       }
//       console.log(`📊 بيانات الشكوى النهائية:`, complaintData);

//       // توليد display ID مخصص
//       const displayId = await generateComplaintDisplayId();
//       complaintData.displayId = displayId;
//       console.log(`📝 Display ID للشكوى: ${displayId}`);

//       // إنشاء الشكوى
//       const complaint = await prisma.complaint.create({
//         data: complaintData,
//         include: {
//           client: true,
//           property: true,
//           unit: true,
//         },
//       });
//       console.log(`✅ تم إنشاء الشكوى بنجاح: ${complaint.id}`);

//       // إرسال الإشعارات الموثوقة لخدمة العملاء
//       try {
//         console.log(`📤 إرسال إشعارات الشكوى #${complaint.id}...`);
//         const notificationResult = await sendComplaintNotifications({
//           complaintId: complaint.id,
//           displayId: complaint.displayId,
//           clientName: client.name,
//           clientPhone: phoneNumber,
//           complaintType: complaint.type,
//           priority: complaint.priority,
//           description: description,
//           propertyName: property?.name || "غير محدد",
//           unitNumber:
//             unit?.number ||
//             unit?.unitId ||
//             `الطابق ${unit?.floor || "غير محدد"}` ||
//             "غير محدد",
//         });

//         console.log(`📤 نتيجة إرسال الإشعارات:`, notificationResult);

//         if (notificationResult.success) {
//           console.log(
//             `✅ تم إرسال جميع الإشعارات بنجاح (${notificationResult.successCount}/${notificationResult.totalCount})`
//           );
//         } else {
//           console.log(
//             `⚠️ فشل في إرسال بعض الإشعارات (${notificationResult.successCount}/${notificationResult.totalCount})`
//           );
//         }
//       } catch (notificationError) {
//         console.error(`❌ خطأ في إرسال الإشعارات:`, notificationError);
//         // لا نوقف العملية حتى لو فشلت الإشعارات
//       }

//       return {
//         success: true,
//         message: "تم إنشاء الشكوى بنجاح",
//         data: {
//           complaint: complaint,
//           client: client,
//           property: property,
//           unit: unit,
//         },
//       };
//     } catch (error) {
//       console.error("❌ خطأ في إنشاء الشكوى:", error);
//       console.error("📋 تفاصيل الخطأ الكاملة:", {
//         name: error.name,
//         message: error.message,
//         stack: error.stack,
//         phoneNumber: phoneNumber,
//         session: session,
//       });

//       return {
//         success: false,
//         message: "حدث خطأ أثناء إنشاء الشكوى",
//         data: null,
//         error: error.message,
//       };
//     }
//   });
// }

// export async function getClientRequestHistory(phoneNumber, limit = 10) {
//   return await withReadOnlyConnection(async (prisma) => {
//     try {
//       // البحث عن العميل
//       const clientData = await findClientWithPropertyProduction(phoneNumber);

//       if (!clientData.success || !clientData.client) {
//         return {
//           success: false,
//           message: "لم يتم العثور على العميل",
//           data: null,
//         };
//       }

//       const client = clientData.client;

//       // البحث عن طلبات الصيانة
//       const maintenanceRequests = await prisma.maintenanceRequest.findMany({
//         where: { clientId: client.id },
//         include: {
//           property: true,
//           unit: true,
//         },
//         orderBy: { createdAt: "desc" },
//         take: limit,
//       });

//       // البحث عن الشكاوى
//       const complaints = await prisma.complaint.findMany({
//         where: { clientId: client.id },
//         include: {
//           property: true,
//           unit: true,
//         },
//         orderBy: { createdAt: "desc" },
//         take: limit,
//       });

//       return {
//         success: true,
//         message: "تم جلب تاريخ الطلبات بنجاح",
//         data: {
//           client: client,
//           maintenanceRequests: maintenanceRequests,
//           complaints: complaints,
//           totalMaintenanceRequests: maintenanceRequests.length,
//           totalComplaints: complaints.length,
//           totalRequests: maintenanceRequests.length + complaints.length,
//         },
//       };
//     } catch (error) {
//       console.error("خطأ في جلب تاريخ الطلبات:", error);
//       return {
//         success: false,
//         message: "حدث خطأ أثناء جلب تاريخ الطلبات",
//         data: null,
//         error: error.message,
//       };
//     }
//   });
// }

// async function sendLanguage(phone) {
//   try {
//     await sendInteractiveWhatsAppMessage(phone, menuLanguage());
//     setSession(phone, { step: "awaiting_language_selection" });
//   } catch {
//     await sendWhatsAppMessage(
//       phone,
//       "Reply with:\n1 - English\n2 - العربية\n\nاكتب:\n1 - English\n2 - العربية"
//     );
//   }
// }

// async function sendMain(phone, language) {
//   try {
//     await sendInteractiveWhatsAppMessage(phone, menuMain(language));
//     setSession(phone, { language, step: "awaiting_main_menu_selection" });
//   } catch {
//     const ar = language === "ARABIC";
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "اختر:\n1️⃣ صيانة\n2️⃣ شكوى\n3️⃣ حالة الطلبات\n4️⃣ دعم\n5️⃣ دفعات\n6️⃣ تجديد عقد"
//         : "Choose:\n1️⃣ Maintenance\n2️⃣ Complaint\n3️⃣ Status\n4️⃣ Support\n5️⃣ Payments\n6️⃣ Contract renewal"
//     );
//   }
// }

// /* =================================
//    Interactive handlers (buttons/lists)
//    ================================= */
// async function onButton(buttonId, phone) {
//   if (buttonId === "lang_en") return sendMain(phone, "ENGLISH");
//   if (buttonId === "lang_ar") return sendMain(phone, "ARABIC");
//   // Unknown buttons are ignored gracefully
// }

// async function onList(listId, phone) {
//   const sess = getSession(phone) || setSession(phone, {});
//   const language = sess.language || "ARABIC";

//   // Global “back to menu” (if you add such a row id later)
//   if (listId === "main_menu" || listId === "back_to_menu") {
//     setSession(phone, { step: "awaiting_main_menu_selection", data: {} });
//     return sendMain(phone, language);
//   }

//   switch (sess.step) {
//     case "awaiting_main_menu_selection":
//       return routeMainMenu(listId, phone, language);
//     case "awaiting_maintenance_type":
//       setSession(phone, {
//         data: { ...(sess.data || {}), maintenanceType: listId },
//       });
//       return sendPriority(phone, language);
//     case "awaiting_priority_selection":
//       setSession(phone, { data: { ...(sess.data || {}), priority: listId } });
//       return askMaintenanceDescription(phone, language);
//     case "awaiting_complaint_category":
//       setSession(phone, { data: { ...(sess.data || {}), category: listId } });
//       return askComplaintDescription(phone, language);
//     case "completed":
//       return sendMain(phone, language);
//     default:
//       return sendMain(phone, language);
//   }
// }

// /* ===========================
//    Text handlers (by session)
//    =========================== */
// async function onText(text, phone) {
//   const sess = getSession(phone);
//   if (!sess) return sendLanguage(phone);

//   const language = sess.language || "ARABIC";
//   const ar = language === "ARABIC";
//   const t = (text || "").toLowerCase().trim();

//   switch (sess.step) {
//     case "awaiting_language_selection":
//       if (t === "1" || t.includes("english")) return sendMain(phone, "ENGLISH");
//       if (t === "2" || t.includes("عرب")) return sendMain(phone, "ARABIC");
//       return sendLanguage(phone);

//     case "awaiting_description": {
//       // Maintenance finalize
//       const res = await createMaintenanceRequestProduction(phone, text, sess);
//       if (!res?.success) {
//         const msg = ar
//           ? "❌ تعذر إنشاء طلب الصيانة. يرجى المحاولة لاحقاً أو الاتصال بنا: +971507935566"
//           : "❌ Could not submit maintenance request. Please try later or call: +971507935566";
//         await sendWhatsAppMessage(phone, msg);
//         return sendMain(phone, language);
//       }
//       const id = res.data?.request?.displayId || res.data?.request?.id;
//       await sendWhatsAppMessage(
//         phone,
//         ar
//           ? `✅ تم تقديم طلب الصيانة.\n📋 رقم الطلب: \u202D${id}\u202C`
//           : `✅ Maintenance request submitted.\n📋 Request #: \u202D${id}\u202C`
//       );
//       setSession(phone, { data: {}, step: "completed" });
//       return;
//     }

//     case "awaiting_complaint_description": {
//       // Complaint finalize
//       const res = await createComplaintProduction(phone, text, sess);
//       if (!res?.success) {
//         const msg = ar
//           ? "❌ تعذر إنشاء الشكوى. يرجى المحاولة لاحقاً أو الاتصال بنا: +971507935566"
//           : "❌ Could not submit complaint. Please try later or call: +971507935566";
//         await sendWhatsAppMessage(phone, msg);
//         return sendMain(phone, language);
//       }
//       const id = res.data?.complaint?.displayId || res.data?.complaint?.id;
//       await sendWhatsAppMessage(
//         phone,
//         ar
//           ? `✅ تم تقديم الشكوى.\n📋 رقم الشكوى: \u202D${id}\u202C`
//           : `✅ Complaint submitted.\n📋 Complaint #: \u202D${id}\u202C`
//       );
//       setSession(phone, { data: {}, step: "completed" });
//       return;
//     }

//     case "completed":
//       if (
//         ["menu", "help", "service", "خدمة", "قائمة"].some((w) => t.includes(w))
//       ) {
//         return sendMain(phone, language);
//       }
//       return sendMain(phone, language);

//     default:
//       return sendMain(phone, language);
//   }
// }

// /* ==============================
//    Flow helpers for menu branches
//    ============================== */
// async function routeMainMenu(choiceId, phone, language) {
//   switch (choiceId) {
//     case "maintenance_request":
//       try {
//         await sendInteractiveWhatsAppMessage(
//           phone,
//           menuMaintenanceType(language)
//         );
//       } catch {
//         await sendWhatsAppMessage(
//           phone,
//           language === "ARABIC" ? "اختر نوع الصيانة" : "Choose maintenance type"
//         );
//       }
//       setSession(phone, { step: "awaiting_maintenance_type" });
//       return;

//     case "submit_complaint":
//       try {
//         await sendInteractiveWhatsAppMessage(
//           phone,
//           menuComplaintCategory(language)
//         );
//       } catch {
//         await sendWhatsAppMessage(
//           phone,
//           language === "ARABIC" ? "اختر نوع الشكوى" : "Choose complaint type"
//         );
//       }
//       setSession(phone, { step: "awaiting_complaint_category" });
//       return;

//     case "check_status":
//       return handleStatus(phone, language);

//     case "contact_support":
//       return handleSupport(phone, language);

//     case "payment_inquiry":
//       return handlePayments(phone, language);

//     case "contract_renewal":
//       return handleRenewal(phone, language);

//     default:
//       return sendMain(phone, language);
//   }
// }

// async function sendPriority(phone, language) {
//   try {
//     await sendInteractiveWhatsAppMessage(phone, menuPriority(language));
//   } catch {
//     const ar = language === "ARABIC";
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "اختر الأولوية (عاجل/عالية/متوسطة/منخفضة)"
//         : "Choose priority (Urgent/High/Medium/Low)"
//     );
//   }
//   setSession(phone, { step: "awaiting_priority_selection" });
// }

// async function askMaintenanceDescription(phone, language) {
//   const ar = language === "ARABIC";
//   await sendWhatsAppMessage(
//     phone,
//     ar
//       ? "من فضلك اكتب وصف المشكلة بالتفصيل."
//       : "Please describe the issue in detail."
//   );
//   setSession(phone, { step: "awaiting_description" });
// }

// async function askComplaintDescription(phone, language) {
//   const ar = language === "ARABIC";
//   await sendWhatsAppMessage(
//     phone,
//     ar ? "من فضلك اكتب تفاصيل الشكوى." : "Please write the complaint details."
//   );
//   setSession(phone, { step: "awaiting_complaint_description" });
// }

// /* =========================================
//    Services: status / support / payments / renewal
//    ========================================= */
// async function handleStatus(phone, language) {
//   const ar = language === "ARABIC";
//   const res = await getClientRequestHistory(phone, 5);
//   if (!res?.success) {
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "❌ لم نجد حسابك. يرجى الاتصال: +971507935566"
//         : "❌ We couldn't find your account. Please call: +971507935566"
//     );
//     return sendMain(phone, language);
//   }

//   const {
//     client,
//     maintenanceRequests = [],
//     complaints = [],
//     totalRequests = 0,
//   } = res.data || {};
//   if (!totalRequests) {
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? `📊 لا توجد طلبات سابقة، ${client?.name || ""}`
//         : `📊 No previous requests, ${client?.name || ""}`
//     );
//     return sendMain(phone, language);
//   }

//   let msg = ar
//     ? `📊 حالة طلبات ${client?.name}\n\n`
//     : `📊 ${client?.name}'s Requests\n\n`;

//   if (maintenanceRequests.length) {
//     msg += ar
//       ? `🔧 طلبات الصيانة (${maintenanceRequests.length}):\n`
//       : `🔧 Maintenance (${maintenanceRequests.length}):\n`;
//     maintenanceRequests.forEach((r, i) => {
//       const id = r.displayId || r.id;
//       msg += `${i + 1}. #\u202D${id}\u202C • ${r.status}\n`;
//     });
//     msg += "\n";
//   }

//   if (complaints.length) {
//     msg += ar
//       ? `📝 الشكاوى (${complaints.length}):\n`
//       : `📝 Complaints (${complaints.length}):\n`;
//     complaints.forEach((c, i) => {
//       const id = c.displayId || c.id;
//       msg += `${i + 1}. #\u202D${id}\u202C • ${c.status}\n`;
//     });
//     msg += "\n";
//   }

//   await sendWhatsAppMessage(phone, msg.trim());
//   return sendMain(phone, language);
// }

// async function handleSupport(phone, language) {
//   const ar = language === "ARABIC";
//   const found = await findClientWithPropertyProduction(phone);
//   if (!found?.success || !found?.client) {
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "❌ لم نجد حسابك. يرجى الاتصال: +971507935566"
//         : "❌ We couldn't find your account. Please call: +971507935566"
//     );
//     return sendMain(phone, language);
//   }
//   // Log a contact intent
//   await withWriteConnection(async (prisma) => {
//     await prisma.contact.create({
//       data: {
//         name: found.client.name,
//         phone,
//         description: `طلب دعم عبر البوت - ${new Date().toISOString()}`,
//       },
//     });
//   });

//   await sendWhatsAppMessage(
//     phone,
//     ar
//       ? "✅ تم تسجيل طلب الدعم. سيتواصل معك فريقنا قريباً."
//       : "✅ Support request recorded. Our team will contact you shortly."
//   );
//   return sendMain(phone, language);
// }

// async function handlePayments(phone, language) {
//   const ar = language === "ARABIC";
//   const found = await findClientWithPropertyProduction(phone);
//   if (!found?.success || !found?.client) {
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "❌ لم نجد حسابك. اتصل بنا للاستعلام عن الدفعات."
//         : "❌ We couldn't find your account. Please call us for payment info."
//     );
//     return sendMain(phone, language);
//   }

//   await withReadOnlyConnection(async (prisma) => {
//     const agreements = await prisma.rentAgreement.findMany({
//       where: { renterId: found.client.id },
//       include: {
//         property: true,
//         unit: true,
//         payments: {
//           where: { status: "PENDING" },
//           orderBy: { dueDate: "asc" },
//           take: 3,
//         },
//       },
//     });

//     if (!agreements.length) {
//       await sendWhatsAppMessage(
//         phone,
//         ar ? "لا توجد دفعات معلقة." : "No pending payments."
//       );
//       return;
//     }

//     let text = ar ? "💳 الدفعات المستحقة:\n\n" : "💳 Pending payments:\n\n";
//     for (const ag of agreements) {
//       for (const p of ag.payments) {
//         const id = p.displayId || p.id;
//         const due = new Date(p.dueDate).toLocaleDateString("en-US");
//         text += ar
//           ? `#\u202D${id}\u202C • ${ag.property?.name || ""} • ${ag.unit?.number || ""}\n📅 ${due} • 💰 ${p.amount} درهم\n\n`
//           : `#\u202D${id}\u202C • ${ag.property?.name || ""} • ${ag.unit?.number || ""}\n📅 ${due} • 💰 ${p.amount} AED\n\n`;
//       }
//     }
//     await sendWhatsAppMessage(phone, text.trim());
//   });

//   return sendMain(phone, language);
// }

// async function handleRenewal(phone, language) {
//   const ar = language === "ARABIC";
//   const found = await findClientWithPropertyProduction(phone);
//   if (!found?.success || !found?.client) {
//     await sendWhatsAppMessage(
//       phone,
//       ar
//         ? "❌ لم نجد حسابك. اتصل بنا لتجديد العقد."
//         : "❌ We couldn't find your account. Please call us for renewal."
//     );
//     return sendMain(phone, language);
//   }

//   await withWriteConnection(async (prisma) => {
//     await prisma.contact.create({
//       data: {
//         name: found.client.name,
//         phone,
//         description: `طلب تجديد عقد عبر البوت - ${new Date().toISOString()}`,
//       },
//     });
//   });

//   await sendWhatsAppMessage(
//     phone,
//     ar
//       ? "✅ تم تسجيل طلب التجديد. سيتواصل معك فريق المبيعات خلال 24 ساعة."
//       : "✅ Renewal request recorded. Sales team will contact you within 24 hours."
//   );
//   return sendMain(phone, language);
// }

// /* ======================================
//    Public: GET (verification) & POST (events)
//    ====================================== */

// // GET /api/whatsapp/webhook
// export async function GET(request) {
//   try {
//     const { searchParams } = new URL(request.url);
//     const mode = searchParams.get("hub.mode");
//     const token = searchParams.get("hub.verify_token");
//     const challenge = searchParams.get("hub.challenge");

//     if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
//       return new Response(challenge, {
//         status: 200,
//         headers: { "Content-Type": "text/plain" },
//       });
//     }
//     return NextResponse.json({ error: "Verification failed" }, { status: 403 });
//   } catch (e) {
//     return NextResponse.json({ error: "Internal error" }, { status: 500 });
//   }
// }

// // POST /api/whatsapp/webhook
// export async function POST(request) {
//   try {
//     const body = await request.json();
//     const entries = body?.entry || [];

//     for (const entry of entries) {
//       const changes = entry?.changes || [];
//       for (const change of changes) {
//         const value = change?.value;
//         const messages = value?.messages || [];

//         for (const msg of messages) {
//           const msgId = msg?.id;
//           if (!msgId) continue;
//           if (processedMsgIds.has(msgId)) continue;
//           processedMsgIds.add(msgId);

//           const from = msg?.from;
//           // لو مفيش from، كمل للرسالة اللي بعدها
//           if (!from) continue;

//           // ✅ غلّف كل رسالة في try/catch علشان نرد للمستخدم لو حصل خطأ
//           try {
//             const { e164, core } = normalizePhone(from);
//             // ابحث مرّتين زي ما طلبت
//             await findClientWithPropertyProduction(e164);
//             await findClientWithPropertyProduction(core);

//             setSession(from, {});

//             const interactive = msg?.interactive;
//             if (interactive) {
//               if (interactive.type === "button_reply") {
//                 await onButton(interactive.button_reply?.id, from);
//               } else if (interactive.type === "list_reply") {
//                 await onList(interactive.list_reply?.id, from);
//               }
//               continue;
//             }

//             const text = msg?.text?.body;
//             if (typeof text === "string") {
//               await onText(text, from);
//               continue;
//             }

//             // لو أضافنا المستخدم بدون رسالة
//             await sendLanguage(from);
//           } catch (perMessageErr) {
//             console.error("Per-message error:", perMessageErr);

//             // ✅ رد فوري للمستخدم بالعربي/إنجليزي:
//             const apologyAR =
//               "❌ حدث خطأ غير متوقع أثناء معالجة رسالتك.\n" +
//               "يرجى المحاولة لاحقًا أو التواصل مع خدمة العملاء على: +971507935566";
//             const apologyEN =
//               "❌ An unexpected error occurred while processing your message.\n" +
//               "Please try again later or contact Customer Service at: +971507935566";

//             try {
//               await sendWhatsAppMessage(from, `${apologyAR}\n\n${apologyEN}`);
//             } catch (notifyErr) {
//               console.error(
//                 "Failed to notify user about the error:",
//                 notifyErr
//               );
//             }
//             // نكمل لباقي الرسائل
//             continue;
//           }
//         }
//       }
//     }
//     return NextResponse.json({ success: true });
//   } catch (e) {
//     console.error("Webhook POST error (outer):", e);
//     // هنا مفيش from متاح بسهولة، فبنرجّع JSON للميتا بس
//     return NextResponse.json(
//       { success: false, error: e?.message || "error" },
//       { status: 200 }
//     );
//   }
// }
